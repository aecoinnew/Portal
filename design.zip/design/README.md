# Emcoin Investment Portal

Production-ready local investment portal for Emcoin Investment.

## Stack

- Frontend: Next.js App Router, TypeScript, Tailwind CSS
- Backend: Node.js, Express, JWT auth, bcrypt password hashing
- Database: SQLite with `better-sqlite3`, no ORM
- File storage: local filesystem for PDF statements
- Charts: Recharts
- Icons: Lucide React

## Setup

```powershell
npm.cmd install
Copy-Item .env.example .env
npm.cmd run db:init
npm.cmd run db:seed
npm.cmd run dev
```

Frontend: `http://localhost:3000`

API: `http://localhost:4000/api`

## Seed Logins

Admin:

```text
admin@emcoin.local
Emcoin#2026
```

Client:

```text
faisal.al-harbi@example.com
Emcoin#2026
```

## Security Notes

- Clients are blocked from admin APIs with role middleware.
- Suspended users are rejected by authentication middleware.
- Client ownership is enforced in API routes for portfolios and statements.
- Statement PDFs are stored under `server/uploads/statements` and served only through authenticated API downloads.
- Admin mutations write audit rows to `audit_logs`.

## Scripts

```powershell
npm.cmd run dev        # API and web dev servers
npm.cmd run dev:api    # Express API only
npm.cmd run dev:web    # Next.js only
npm.cmd run db:init    # create SQLite schema
npm.cmd run db:seed    # seed users, products, prices, positions, requests, sample PDF
npm.cmd run type-check
npm.cmd run build
```

## Routes

Client:

- `/login`
- `/client/dashboard`
- `/client/portfolio`
- `/client/statements`
- `/client/requests`

Admin:

- `/admin/dashboard`
- `/admin/clients`
- `/admin/products`
- `/admin/portfolios`
- `/admin/pricing`
- `/admin/requests`
- `/admin/statements`
- `/admin/settings`

## Currency

The portal uses AED as the default base currency. Admins can enable or disable USD selection from `/admin/settings`; products and investment requests support AED and, when enabled, USD.

## Data Paths

- SQLite database: `server/data/emcoin.sqlite`
- Statements: `server/uploads/statements`

Both paths are ignored by Git.
