"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPortfolioSummary = getPortfolioSummary;
exports.getTotalAum = getTotalAum;
const portfolio_js_1 = require("../../lib/calculations/portfolio.js");
const connection_js_1 = require("../db/connection.js");
function getPortfolioSummary(userId) {
    const rows = connection_js_1.db
        .prepare(`
      SELECT
        pp.id AS position_id,
        pp.user_id,
        p.id AS product_id,
        p.name AS product_name,
        p.symbol,
        p.type,
        p.pricing_mode,
        p.currency,
        pp.quantity,
        pp.avg_price,
        pr.price AS current_price,
        pr.updated_at AS price_updated_at
      FROM portfolio_positions pp
      JOIN products p ON p.id = pp.product_id
      LEFT JOIN prices pr ON pr.product_id = p.id
      WHERE pp.user_id = ?
      ORDER BY p.type, p.name
      `)
        .all(userId);
    const holdings = rows.map((row) => (0, portfolio_js_1.calculateHolding)({
        positionId: row.position_id,
        userId: row.user_id,
        productId: row.product_id,
        productName: row.product_name,
        symbol: row.symbol,
        type: row.type,
        pricingMode: row.pricing_mode,
        currency: row.currency,
        quantity: Number(row.quantity),
        avgPrice: Number(row.avg_price),
        currentPrice: Number(row.current_price ?? 0),
        priceUpdatedAt: row.price_updated_at
    }));
    return {
        userId,
        ...(0, portfolio_js_1.calculatePortfolioTotals)(holdings),
        allocation: (0, portfolio_js_1.calculateAllocation)(holdings),
        holdings
    };
}
function getTotalAum() {
    const clientRows = connection_js_1.db
        .prepare("SELECT id FROM users WHERE role = 'client' AND status = 'active'")
        .all();
    return clientRows.reduce((sum, row) => sum + getPortfolioSummary(row.id).totalValue, 0);
}
