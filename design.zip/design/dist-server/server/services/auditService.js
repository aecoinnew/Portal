"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.auditLog = auditLog;
const connection_js_1 = require("../db/connection.js");
function auditLog(admin, action, entityType, entityId, metadata) {
    if (admin.role !== "admin")
        return;
    connection_js_1.db.prepare(`
    INSERT INTO audit_logs (id, admin_user_id, action, entity_type, entity_id, metadata, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run((0, connection_js_1.uid)("aud"), admin.id, action, entityType, entityId, metadata ? JSON.stringify(metadata) : null, (0, connection_js_1.nowIso)());
}
