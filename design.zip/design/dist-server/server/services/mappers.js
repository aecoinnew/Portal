"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapClient = mapClient;
exports.mapProduct = mapProduct;
exports.mapPrice = mapPrice;
exports.mapRequest = mapRequest;
exports.mapStatement = mapStatement;
exports.mapAudit = mapAudit;
function mapClient(row) {
    return {
        id: String(row.id),
        name: String(row.name),
        email: String(row.email),
        role: row.role,
        status: row.status,
        phone: row.phone ?? null,
        relationshipManager: row.relationship_manager ?? null,
        createdAt: String(row.created_at),
        updatedAt: String(row.updated_at)
    };
}
function mapProduct(row) {
    return {
        id: String(row.id),
        name: String(row.name),
        symbol: row.symbol ?? null,
        type: row.type,
        pricingMode: row.pricing_mode,
        currency: row.currency,
        isActive: Boolean(row.is_active),
        createdAt: String(row.created_at),
        updatedAt: String(row.updated_at)
    };
}
function mapPrice(row) {
    return {
        id: String(row.id),
        productId: String(row.product_id),
        price: Number(row.price),
        source: row.source,
        updatedAt: String(row.updated_at)
    };
}
function mapRequest(row) {
    return {
        id: String(row.id),
        userId: String(row.user_id),
        clientName: row.client_name ?? undefined,
        type: row.type,
        productId: row.product_id ?? null,
        productName: row.product_name ?? null,
        amount: row.amount == null ? null : Number(row.amount),
        currency: row.currency ?? "AED",
        message: String(row.message ?? ""),
        status: row.status,
        rejectionReason: row.rejection_reason ?? null,
        createdAt: String(row.created_at),
        updatedAt: String(row.updated_at)
    };
}
function mapStatement(row) {
    return {
        id: String(row.id),
        userId: String(row.user_id),
        clientName: row.client_name ?? undefined,
        period: String(row.period),
        fileName: String(row.file_name),
        fileSize: Number(row.file_size ?? 0),
        createdAt: String(row.created_at)
    };
}
function mapAudit(row) {
    return {
        id: String(row.id),
        adminUserId: String(row.admin_user_id),
        adminName: row.admin_name ?? undefined,
        action: String(row.action),
        entityType: String(row.entity_type),
        entityId: String(row.entity_id),
        metadata: row.metadata ?? null,
        createdAt: String(row.created_at)
    };
}
