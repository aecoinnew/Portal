"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.statementsDir = exports.databasePath = exports.db = void 0;
exports.nowIso = nowIso;
exports.uid = uid;
exports.resolveStatementPath = resolveStatementPath;
const better_sqlite3_1 = __importDefault(require("better-sqlite3"));
const dotenv_1 = __importDefault(require("dotenv"));
const node_crypto_1 = require("node:crypto");
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
dotenv_1.default.config();
const databasePath = node_path_1.default.resolve(process.cwd(), process.env.DATABASE_PATH ?? "server/data/emcoin.sqlite");
exports.databasePath = databasePath;
const statementsDir = node_path_1.default.resolve(process.cwd(), process.env.STATEMENTS_DIR ?? "server/uploads/statements");
exports.statementsDir = statementsDir;
node_fs_1.default.mkdirSync(node_path_1.default.dirname(databasePath), { recursive: true });
node_fs_1.default.mkdirSync(statementsDir, { recursive: true });
exports.db = new better_sqlite3_1.default(databasePath);
exports.db.pragma("foreign_keys = ON");
exports.db.pragma("journal_mode = WAL");
function nowIso() {
    return new Date().toISOString();
}
function uid(prefix) {
    return `${prefix}_${(0, node_crypto_1.randomUUID)().replace(/-/g, "")}`;
}
function resolveStatementPath(filePath) {
    const resolved = node_path_1.default.resolve(filePath);
    if (!resolved.startsWith(statementsDir)) {
        throw new Error("Invalid statement storage path");
    }
    return resolved;
}
