"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authRouter = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const express_1 = require("express");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const zod_1 = require("zod");
const connection_js_1 = require("../db/connection.js");
const auth_js_1 = require("../middleware/auth.js");
const error_js_1 = require("../middleware/error.js");
exports.authRouter = (0, express_1.Router)();
const loginSchema = zod_1.z.object({
    email: zod_1.z.string().email(),
    password: zod_1.z.string().min(1)
});
exports.authRouter.post("/login", async (req, res, next) => {
    try {
        const body = loginSchema.parse(req.body);
        const row = connection_js_1.db
            .prepare("SELECT id, name, email, password_hash, role, status FROM users WHERE email = ?")
            .get(body.email);
        if (!row) {
            throw new error_js_1.ApiError(401, "Incorrect email or password", "invalid_credentials");
        }
        const validPassword = await bcrypt_1.default.compare(body.password, row.password_hash);
        if (!validPassword) {
            throw new error_js_1.ApiError(401, "Incorrect email or password", "invalid_credentials");
        }
        if (row.status === "suspended") {
            throw new error_js_1.ApiError(403, "Account is suspended", "account_suspended");
        }
        const user = {
            id: row.id,
            name: row.name,
            email: row.email,
            role: row.role,
            status: row.status
        };
        const signOptions = {
            expiresIn: (process.env.JWT_EXPIRES_IN ?? "8h")
        };
        const token = jsonwebtoken_1.default.sign({ sub: user.id, role: user.role }, (0, auth_js_1.jwtSecret)(), signOptions);
        res.json({ token, user });
    }
    catch (error) {
        next(error);
    }
});
exports.authRouter.get("/me", auth_js_1.authenticate, (req, res) => {
    res.json({ user: req.user });
});
