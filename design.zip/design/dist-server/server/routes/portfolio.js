"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.portfolioRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const connection_js_1 = require("../db/connection.js");
const auth_js_1 = require("../middleware/auth.js");
const error_js_1 = require("../middleware/error.js");
const auditService_js_1 = require("../services/auditService.js");
const portfolioService_js_1 = require("../services/portfolioService.js");
exports.portfolioRouter = (0, express_1.Router)();
const positionSchema = zod_1.z.object({
    userId: zod_1.z.string().min(1),
    productId: zod_1.z.string().min(1),
    quantity: zod_1.z.coerce.number().nonnegative(),
    avgPrice: zod_1.z.coerce.number().nonnegative()
});
const positionPatchSchema = zod_1.z.object({
    userId: zod_1.z.string().min(1).optional(),
    productId: zod_1.z.string().min(1).optional(),
    quantity: zod_1.z.coerce.number().nonnegative().optional(),
    avgPrice: zod_1.z.coerce.number().nonnegative().optional()
});
exports.portfolioRouter.use(auth_js_1.authenticate);
exports.portfolioRouter.get("/me", (req, res) => {
    const user = req.user;
    res.json({ portfolio: (0, portfolioService_js_1.getPortfolioSummary)(user.id) });
});
exports.portfolioRouter.get("/positions", auth_js_1.requireAdmin, (_req, res) => {
    const rows = connection_js_1.db
        .prepare(`
      SELECT
        pp.id,
        pp.user_id AS userId,
        u.name AS clientName,
        pp.product_id AS productId,
        p.name AS productName,
        p.type,
        p.currency,
        pp.quantity,
        pp.avg_price AS avgPrice,
        COALESCE(pr.price, 0) AS currentPrice,
        pp.quantity * pp.avg_price AS costBasis,
        pp.quantity * COALESCE(pr.price, 0) AS marketValue,
        pp.quantity * (COALESCE(pr.price, 0) - pp.avg_price) AS unrealizedPnL,
        pp.updated_at AS updatedAt
      FROM portfolio_positions pp
      JOIN users u ON u.id = pp.user_id
      JOIN products p ON p.id = pp.product_id
      LEFT JOIN prices pr ON pr.product_id = pp.product_id
      ORDER BY u.name, p.name
      `)
        .all();
    res.json({ positions: rows });
});
exports.portfolioRouter.post("/positions", auth_js_1.requireAdmin, (req, res, next) => {
    try {
        const body = positionSchema.parse(req.body);
        const admin = req.user;
        assertClient(body.userId);
        assertProduct(body.productId);
        const id = (0, connection_js_1.uid)("pos");
        const timestamp = (0, connection_js_1.nowIso)();
        connection_js_1.db.prepare(`
      INSERT INTO portfolio_positions (id, user_id, product_id, quantity, avg_price, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id, product_id) DO UPDATE SET
        quantity = excluded.quantity,
        avg_price = excluded.avg_price,
        updated_at = excluded.updated_at
      `).run(id, body.userId, body.productId, body.quantity, body.avgPrice, timestamp, timestamp);
        (0, auditService_js_1.auditLog)(admin, "portfolio.position.upserted", "portfolio_position", id, body);
        res.status(201).json({ portfolio: (0, portfolioService_js_1.getPortfolioSummary)(body.userId) });
    }
    catch (error) {
        next(error);
    }
});
exports.portfolioRouter.patch("/positions/:id", auth_js_1.requireAdmin, (req, res, next) => {
    try {
        const body = positionPatchSchema.parse(req.body);
        const admin = req.user;
        const existing = connection_js_1.db
            .prepare("SELECT id, user_id FROM portfolio_positions WHERE id = ?")
            .get(req.params.id);
        if (!existing)
            throw new error_js_1.ApiError(404, "Position not found", "position_not_found");
        const updates = [];
        const values = [];
        const set = (column, value) => {
            updates.push(`${column} = ?`);
            values.push(value);
        };
        if (body.userId !== undefined) {
            assertClient(body.userId);
            set("user_id", body.userId);
        }
        if (body.productId !== undefined) {
            assertProduct(body.productId);
            set("product_id", body.productId);
        }
        if (body.quantity !== undefined)
            set("quantity", body.quantity);
        if (body.avgPrice !== undefined)
            set("avg_price", body.avgPrice);
        if (updates.length > 0) {
            set("updated_at", (0, connection_js_1.nowIso)());
            connection_js_1.db.prepare(`UPDATE portfolio_positions SET ${updates.join(", ")} WHERE id = ?`).run(...values, req.params.id);
            (0, auditService_js_1.auditLog)(admin, "portfolio.position.updated", "portfolio_position", req.params.id, body);
        }
        res.json({ portfolio: (0, portfolioService_js_1.getPortfolioSummary)(body.userId ?? existing.user_id) });
    }
    catch (error) {
        if (String(error).includes("UNIQUE constraint failed")) {
            return next(new error_js_1.ApiError(409, "That client already has this product position", "position_exists"));
        }
        return next(error);
    }
});
exports.portfolioRouter.delete("/positions/:id", auth_js_1.requireAdmin, (req, res, next) => {
    try {
        const admin = req.user;
        const existing = connection_js_1.db
            .prepare("SELECT id, user_id FROM portfolio_positions WHERE id = ?")
            .get(req.params.id);
        if (!existing)
            throw new error_js_1.ApiError(404, "Position not found", "position_not_found");
        connection_js_1.db.prepare("DELETE FROM portfolio_positions WHERE id = ?").run(req.params.id);
        (0, auditService_js_1.auditLog)(admin, "portfolio.position.deleted", "portfolio_position", req.params.id, {
            userId: existing.user_id
        });
        res.status(204).send();
    }
    catch (error) {
        next(error);
    }
});
exports.portfolioRouter.get("/:userId", (0, auth_js_1.requireSelfOrAdmin)("userId"), (req, res) => {
    res.json({ portfolio: (0, portfolioService_js_1.getPortfolioSummary)(req.params.userId) });
});
function assertClient(userId) {
    const row = connection_js_1.db.prepare("SELECT id FROM users WHERE id = ? AND role = 'client'").get(userId);
    if (!row)
        throw new error_js_1.ApiError(400, "Client user not found", "client_not_found");
}
function assertProduct(productId) {
    const row = connection_js_1.db.prepare("SELECT id FROM products WHERE id = ?").get(productId);
    if (!row)
        throw new error_js_1.ApiError(400, "Product not found", "product_not_found");
}
