"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminRouter = void 0;
const express_1 = require("express");
const auth_js_1 = require("../middleware/auth.js");
const mappers_js_1 = require("../services/mappers.js");
const portfolioService_js_1 = require("../services/portfolioService.js");
const connection_js_1 = require("../db/connection.js");
exports.adminRouter = (0, express_1.Router)();
exports.adminRouter.use(auth_js_1.authenticate, auth_js_1.requireAdmin);
exports.adminRouter.get("/summary", (_req, res) => {
    const users = connection_js_1.db
        .prepare(`
      SELECT
        COUNT(CASE WHEN role = 'client' THEN 1 END) AS totalClients,
        COUNT(CASE WHEN role = 'client' AND status = 'active' THEN 1 END) AS activeClients,
        COUNT(CASE WHEN role = 'client' AND status = 'suspended' THEN 1 END) AS suspendedClients
      FROM users
      `)
        .get();
    const requests = connection_js_1.db
        .prepare("SELECT COUNT(*) AS pendingRequests FROM investment_requests WHERE status = 'pending'")
        .get();
    const products = connection_js_1.db
        .prepare(`
      SELECT
        COUNT(CASE WHEN is_active = 1 THEN 1 END) AS activeProducts,
        COUNT(CASE WHEN is_active = 1 AND pricing_mode = 'manual' THEN 1 END) AS manualProducts
      FROM products
      `)
        .get();
    const stale = connection_js_1.db
        .prepare(`
      SELECT COUNT(*) AS stalePrices
      FROM products p
      LEFT JOIN prices pr ON pr.product_id = p.id
      WHERE p.is_active = 1
        AND p.pricing_mode = 'manual'
        AND (pr.updated_at IS NULL OR datetime(pr.updated_at) < datetime('now', '-24 hours'))
      `)
        .get();
    const activityRows = connection_js_1.db
        .prepare(`
      SELECT al.*, u.name AS admin_name
      FROM audit_logs al
      JOIN users u ON u.id = al.admin_user_id
      ORDER BY al.created_at DESC
      LIMIT 8
      `)
        .all();
    res.json({
        summary: {
            ...users,
            totalAum: (0, portfolioService_js_1.getTotalAum)(),
            pendingRequests: requests.pendingRequests,
            activeProducts: products.activeProducts,
            manualProducts: products.manualProducts,
            stalePrices: stale.stalePrices,
            recentActivity: activityRows.map(mappers_js_1.mapAudit)
        }
    });
});
