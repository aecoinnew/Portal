"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.clientsRouter = void 0;
const bcrypt_1 = __importDefault(require("bcrypt"));
const express_1 = require("express");
const zod_1 = require("zod");
const connection_js_1 = require("../db/connection.js");
const auth_js_1 = require("../middleware/auth.js");
const error_js_1 = require("../middleware/error.js");
const auditService_js_1 = require("../services/auditService.js");
const mappers_js_1 = require("../services/mappers.js");
exports.clientsRouter = (0, express_1.Router)();
exports.clientsRouter.use(auth_js_1.authenticate, auth_js_1.requireAdmin);
const userCreateSchema = zod_1.z.object({
    name: zod_1.z.string().min(2),
    email: zod_1.z.string().email(),
    password: zod_1.z.string().min(10),
    role: zod_1.z.enum(["client", "admin"]).default("client"),
    status: zod_1.z.enum(["active", "suspended"]).default("active"),
    phone: zod_1.z.string().optional().nullable(),
    relationshipManager: zod_1.z.string().optional().nullable()
});
const userUpdateSchema = zod_1.z.object({
    name: zod_1.z.string().min(2).optional(),
    email: zod_1.z.string().email().optional(),
    password: zod_1.z.string().min(10).optional(),
    role: zod_1.z.enum(["client", "admin"]).optional(),
    status: zod_1.z.enum(["active", "suspended"]).optional(),
    phone: zod_1.z.string().optional().nullable(),
    relationshipManager: zod_1.z.string().optional().nullable()
});
exports.clientsRouter.get("/", (req, res) => {
    const role = req.query.role === "admin" ? "admin" : "client";
    const rows = connection_js_1.db
        .prepare(`
      SELECT id, name, email, role, status, phone, relationship_manager, created_at, updated_at
      FROM users
      WHERE role = ?
      ORDER BY name
      `)
        .all(role);
    res.json({ clients: rows.map(mappers_js_1.mapClient) });
});
exports.clientsRouter.post("/", async (req, res, next) => {
    try {
        const body = userCreateSchema.parse(req.body);
        const admin = req.user;
        const id = (0, connection_js_1.uid)("usr");
        const timestamp = (0, connection_js_1.nowIso)();
        const passwordHash = await bcrypt_1.default.hash(body.password, 12);
        connection_js_1.db.prepare(`
      INSERT INTO users
      (id, name, email, password_hash, role, status, phone, relationship_manager, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, body.name, body.email, passwordHash, body.role, body.status, body.phone ?? null, body.relationshipManager ?? null, timestamp, timestamp);
        (0, auditService_js_1.auditLog)(admin, "user.created", "user", id, {
            email: body.email,
            role: body.role,
            status: body.status
        });
        const row = connection_js_1.db
            .prepare("SELECT id, name, email, role, status, phone, relationship_manager, created_at, updated_at FROM users WHERE id = ?")
            .get(id);
        res.status(201).json({ client: (0, mappers_js_1.mapClient)(row) });
    }
    catch (error) {
        if (String(error).includes("UNIQUE constraint failed")) {
            return next(new error_js_1.ApiError(409, "Email already exists", "email_exists"));
        }
        next(error);
    }
});
exports.clientsRouter.get("/:id", (req, res, next) => {
    const row = connection_js_1.db
        .prepare("SELECT id, name, email, role, status, phone, relationship_manager, created_at, updated_at FROM users WHERE id = ?")
        .get(req.params.id);
    if (!row)
        return next(new error_js_1.ApiError(404, "Client not found", "client_not_found"));
    return res.json({ client: (0, mappers_js_1.mapClient)(row) });
});
exports.clientsRouter.patch("/:id", async (req, res, next) => {
    try {
        const body = userUpdateSchema.parse(req.body);
        const admin = req.user;
        const existing = connection_js_1.db.prepare("SELECT id, role, status FROM users WHERE id = ?").get(req.params.id);
        if (!existing)
            throw new error_js_1.ApiError(404, "Client not found", "client_not_found");
        const updates = [];
        const values = [];
        const set = (column, value) => {
            updates.push(`${column} = ?`);
            values.push(value);
        };
        if (body.name !== undefined)
            set("name", body.name);
        if (body.email !== undefined)
            set("email", body.email);
        if (body.role !== undefined)
            set("role", body.role);
        if (body.status !== undefined)
            set("status", body.status);
        if (body.phone !== undefined)
            set("phone", body.phone);
        if (body.relationshipManager !== undefined)
            set("relationship_manager", body.relationshipManager);
        if (body.password !== undefined)
            set("password_hash", await bcrypt_1.default.hash(body.password, 12));
        if (updates.length > 0) {
            set("updated_at", (0, connection_js_1.nowIso)());
            connection_js_1.db.prepare(`UPDATE users SET ${updates.join(", ")} WHERE id = ?`).run(...values, req.params.id);
            (0, auditService_js_1.auditLog)(admin, "user.updated", "user", req.params.id, {
                fields: Object.keys(body)
            });
        }
        const row = connection_js_1.db
            .prepare("SELECT id, name, email, role, status, phone, relationship_manager, created_at, updated_at FROM users WHERE id = ?")
            .get(req.params.id);
        res.json({ client: (0, mappers_js_1.mapClient)(row) });
    }
    catch (error) {
        if (String(error).includes("UNIQUE constraint failed")) {
            return next(new error_js_1.ApiError(409, "Email already exists", "email_exists"));
        }
        next(error);
    }
});
