"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pricingRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const connection_js_1 = require("../db/connection.js");
const auth_js_1 = require("../middleware/auth.js");
const error_js_1 = require("../middleware/error.js");
const auditService_js_1 = require("../services/auditService.js");
exports.pricingRouter = (0, express_1.Router)();
const priceSchema = zod_1.z.object({
    price: zod_1.z.coerce.number().nonnegative()
});
exports.pricingRouter.use(auth_js_1.authenticate, auth_js_1.requireAdmin);
exports.pricingRouter.get("/", (_req, res) => {
    const rows = connection_js_1.db
        .prepare(`
      SELECT
        p.id AS productId,
        p.name AS productName,
        p.type,
        p.pricing_mode AS pricingMode,
        p.currency,
        p.is_active AS isActive,
        pr.id AS priceId,
        pr.price,
        pr.source,
        pr.updated_at AS updatedAt
      FROM products p
      LEFT JOIN prices pr ON pr.product_id = p.id
      ORDER BY p.type, p.name
      `)
        .all();
    res.json({ pricing: rows });
});
exports.pricingRouter.patch("/:productId", (req, res, next) => {
    try {
        const body = priceSchema.parse(req.body);
        const admin = req.user;
        const product = connection_js_1.db
            .prepare("SELECT id, pricing_mode FROM products WHERE id = ?")
            .get(req.params.productId);
        if (!product)
            throw new error_js_1.ApiError(404, "Product not found", "product_not_found");
        if (product.pricing_mode !== "manual") {
            throw new error_js_1.ApiError(400, "Only manual-priced products can be updated here", "manual_price_required");
        }
        const timestamp = (0, connection_js_1.nowIso)();
        const priceId = (0, connection_js_1.uid)("prc");
        connection_js_1.db.transaction(() => {
            connection_js_1.db.prepare(`
        INSERT INTO prices (id, product_id, price, source, updated_at)
        VALUES (?, ?, ?, 'manual', ?)
        ON CONFLICT(product_id) DO UPDATE SET
          price = excluded.price,
          source = excluded.source,
          updated_at = excluded.updated_at
        `).run(priceId, req.params.productId, body.price, timestamp);
            connection_js_1.db.prepare(`
        INSERT INTO product_price_history (id, product_id, price, source, created_at)
        VALUES (?, ?, ?, 'manual', ?)
        `).run((0, connection_js_1.uid)("hist"), req.params.productId, body.price, timestamp);
        })();
        (0, auditService_js_1.auditLog)(admin, "price.updated", "product", req.params.productId, { price: body.price });
        res.json({ productId: req.params.productId, price: body.price, source: "manual", updatedAt: timestamp });
    }
    catch (error) {
        next(error);
    }
});
