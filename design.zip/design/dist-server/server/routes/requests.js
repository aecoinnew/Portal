"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestsRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const connection_js_1 = require("../db/connection.js");
const auth_js_1 = require("../middleware/auth.js");
const error_js_1 = require("../middleware/error.js");
const auditService_js_1 = require("../services/auditService.js");
const mappers_js_1 = require("../services/mappers.js");
const settings_js_1 = require("./settings.js");
exports.requestsRouter = (0, express_1.Router)();
const createRequestSchema = zod_1.z.object({
    type: zod_1.z.enum(["buy", "sell", "subscribe", "withdraw"]),
    productId: zod_1.z.string().optional().nullable(),
    amount: zod_1.z.coerce.number().nonnegative().optional().nullable(),
    currency: zod_1.z.enum(["AED", "USD"]).default("AED"),
    message: zod_1.z.string().max(2000).optional().default("")
});
const statusSchema = zod_1.z.object({
    status: zod_1.z.enum(["approved", "rejected", "executed"]),
    rejectionReason: zod_1.z.string().max(1000).optional().nullable()
});
exports.requestsRouter.use(auth_js_1.authenticate);
exports.requestsRouter.get("/", (req, res) => {
    const user = req.user;
    const status = typeof req.query.status === "string" ? req.query.status : null;
    const clientId = typeof req.query.clientId === "string" ? req.query.clientId : null;
    const filters = [];
    const values = [];
    if (user.role !== "admin") {
        filters.push("ir.user_id = ?");
        values.push(user.id);
    }
    else if (clientId) {
        filters.push("ir.user_id = ?");
        values.push(clientId);
    }
    if (status) {
        filters.push("ir.status = ?");
        values.push(status);
    }
    const rows = connection_js_1.db
        .prepare(`
      SELECT
        ir.*,
        u.name AS client_name,
        p.name AS product_name
      FROM investment_requests ir
      JOIN users u ON u.id = ir.user_id
      LEFT JOIN products p ON p.id = ir.product_id
      ${filters.length ? `WHERE ${filters.join(" AND ")}` : ""}
      ORDER BY ir.created_at DESC
      `)
        .all(...values);
    res.json({ requests: rows.map(mappers_js_1.mapRequest) });
});
exports.requestsRouter.post("/", (req, res, next) => {
    try {
        const user = req.user;
        if (user.role !== "client") {
            throw new error_js_1.ApiError(403, "Only clients can submit investment requests", "client_required");
        }
        const body = createRequestSchema.parse(req.body);
        if (!(0, settings_js_1.isCurrencyAllowed)(body.currency)) {
            throw new error_js_1.ApiError(400, "USD requests are disabled", "currency_disabled");
        }
        if (body.productId)
            assertActiveProduct(body.productId);
        const timestamp = (0, connection_js_1.nowIso)();
        const id = (0, connection_js_1.uid)("req");
        connection_js_1.db.prepare(`
      INSERT INTO investment_requests
      (id, user_id, type, product_id, amount, currency, message, status, rejection_reason, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', NULL, ?, ?)
      `).run(id, user.id, body.type, body.productId ?? null, body.amount ?? null, body.currency, body.message.trim(), timestamp, timestamp);
        const row = connection_js_1.db
            .prepare(`
        SELECT ir.*, u.name AS client_name, p.name AS product_name
        FROM investment_requests ir
        JOIN users u ON u.id = ir.user_id
        LEFT JOIN products p ON p.id = ir.product_id
        WHERE ir.id = ?
        `)
            .get(id);
        res.status(201).json({ request: (0, mappers_js_1.mapRequest)(row) });
    }
    catch (error) {
        next(error);
    }
});
exports.requestsRouter.patch("/:id/status", auth_js_1.requireAdmin, (req, res, next) => {
    try {
        const body = statusSchema.parse(req.body);
        const admin = req.user;
        const existing = connection_js_1.db.prepare("SELECT id, status FROM investment_requests WHERE id = ?").get(req.params.id);
        if (!existing)
            throw new error_js_1.ApiError(404, "Request not found", "request_not_found");
        if (body.status === "rejected" && !body.rejectionReason?.trim()) {
            throw new error_js_1.ApiError(400, "Rejection reason is required", "rejection_reason_required");
        }
        const timestamp = (0, connection_js_1.nowIso)();
        connection_js_1.db.prepare(`
      UPDATE investment_requests
      SET status = ?, rejection_reason = ?, updated_at = ?
      WHERE id = ?
      `).run(body.status, body.status === "rejected" ? body.rejectionReason?.trim() : null, timestamp, req.params.id);
        (0, auditService_js_1.auditLog)(admin, "request.status.updated", "investment_request", req.params.id, {
            from: existing.status,
            to: body.status
        });
        const row = connection_js_1.db
            .prepare(`
        SELECT ir.*, u.name AS client_name, p.name AS product_name
        FROM investment_requests ir
        JOIN users u ON u.id = ir.user_id
        LEFT JOIN products p ON p.id = ir.product_id
        WHERE ir.id = ?
        `)
            .get(req.params.id);
        res.json({ request: (0, mappers_js_1.mapRequest)(row) });
    }
    catch (error) {
        next(error);
    }
});
function assertActiveProduct(productId) {
    const row = connection_js_1.db.prepare("SELECT id FROM products WHERE id = ? AND is_active = 1").get(productId);
    if (!row)
        throw new error_js_1.ApiError(400, "Active product not found", "product_not_found");
}
