"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.settingsRouter = void 0;
exports.getSettings = getSettings;
exports.isCurrencyAllowed = isCurrencyAllowed;
const express_1 = require("express");
const zod_1 = require("zod");
const connection_js_1 = require("../db/connection.js");
const auth_js_1 = require("../middleware/auth.js");
const auditService_js_1 = require("../services/auditService.js");
exports.settingsRouter = (0, express_1.Router)();
const settingsSchema = zod_1.z.object({
    baseCurrency: zod_1.z.enum(["AED", "USD"]),
    allowUsd: zod_1.z.boolean()
}).refine((settings) => settings.baseCurrency !== "USD" || settings.allowUsd, {
    message: "USD must be allowed when it is the base currency",
    path: ["allowUsd"]
});
exports.settingsRouter.use(auth_js_1.authenticate);
exports.settingsRouter.get("/", (_req, res) => {
    res.json({ settings: getSettings() });
});
exports.settingsRouter.patch("/", auth_js_1.requireAdmin, (req, res, next) => {
    try {
        const body = settingsSchema.parse(req.body);
        const admin = req.user;
        const timestamp = (0, connection_js_1.nowIso)();
        connection_js_1.db.prepare(`
      UPDATE app_settings
      SET base_currency = ?, allow_usd = ?, updated_at = ?
      WHERE id = 'global'
      `).run(body.baseCurrency, body.allowUsd ? 1 : 0, timestamp);
        (0, auditService_js_1.auditLog)(admin, "settings.updated", "app_settings", "global", body);
        res.json({ settings: getSettings() });
    }
    catch (error) {
        next(error);
    }
});
function getSettings() {
    const row = connection_js_1.db
        .prepare("SELECT base_currency, allow_usd, updated_at FROM app_settings WHERE id = 'global'")
        .get();
    return {
        baseCurrency: row?.base_currency ?? "AED",
        allowUsd: Boolean(row?.allow_usd ?? 1),
        updatedAt: row?.updated_at ?? (0, connection_js_1.nowIso)()
    };
}
function isCurrencyAllowed(currency) {
    const settings = getSettings();
    return currency === "AED" || settings.allowUsd;
}
