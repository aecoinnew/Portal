"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.productsRouter = void 0;
const express_1 = require("express");
const zod_1 = require("zod");
const connection_js_1 = require("../db/connection.js");
const auth_js_1 = require("../middleware/auth.js");
const error_js_1 = require("../middleware/error.js");
const auditService_js_1 = require("../services/auditService.js");
const mappers_js_1 = require("../services/mappers.js");
const settings_js_1 = require("./settings.js");
exports.productsRouter = (0, express_1.Router)();
const productSchema = zod_1.z.object({
    name: zod_1.z.string().min(2),
    symbol: zod_1.z.string().optional().nullable(),
    type: zod_1.z.enum(["stock", "crypto", "fund", "sukuk", "private"]),
    pricingMode: zod_1.z.enum(["api", "manual"]),
    currency: zod_1.z.enum(["AED", "USD"]).default("AED"),
    isActive: zod_1.z.boolean().default(true)
});
const productPatchSchema = productSchema.partial();
exports.productsRouter.use(auth_js_1.authenticate);
exports.productsRouter.get("/", (req, res) => {
    const user = req.user;
    const includeInactive = user.role === "admin" && req.query.includeInactive === "true";
    const rows = connection_js_1.db
        .prepare(`
      SELECT id, name, symbol, type, pricing_mode, currency, is_active, created_at, updated_at
      FROM products
      ${includeInactive ? "" : "WHERE is_active = 1"}
      ORDER BY type, name
      `)
        .all();
    res.json({ products: rows.map(mappers_js_1.mapProduct) });
});
exports.productsRouter.post("/", auth_js_1.requireAdmin, (req, res, next) => {
    try {
        const body = productSchema.parse(req.body);
        if (!(0, settings_js_1.isCurrencyAllowed)(body.currency)) {
            throw new error_js_1.ApiError(400, "USD is disabled in admin settings", "currency_disabled");
        }
        const admin = req.user;
        const id = (0, connection_js_1.uid)("prd");
        const timestamp = (0, connection_js_1.nowIso)();
        connection_js_1.db.prepare(`
      INSERT INTO products (id, name, symbol, type, pricing_mode, currency, is_active, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, body.name, body.symbol ?? null, body.type, body.pricingMode, body.currency.toUpperCase(), body.isActive ? 1 : 0, timestamp, timestamp);
        (0, auditService_js_1.auditLog)(admin, "product.created", "product", id, body);
        const row = connection_js_1.db.prepare("SELECT * FROM products WHERE id = ?").get(id);
        res.status(201).json({ product: (0, mappers_js_1.mapProduct)(row) });
    }
    catch (error) {
        next(error);
    }
});
exports.productsRouter.patch("/:id", auth_js_1.requireAdmin, (req, res, next) => {
    try {
        const body = productPatchSchema.parse(req.body);
        if (body.currency && !(0, settings_js_1.isCurrencyAllowed)(body.currency)) {
            throw new error_js_1.ApiError(400, "USD is disabled in admin settings", "currency_disabled");
        }
        const admin = req.user;
        const existing = connection_js_1.db.prepare("SELECT id FROM products WHERE id = ?").get(req.params.id);
        if (!existing)
            throw new error_js_1.ApiError(404, "Product not found", "product_not_found");
        const updates = [];
        const values = [];
        const set = (column, value) => {
            updates.push(`${column} = ?`);
            values.push(value);
        };
        if (body.name !== undefined)
            set("name", body.name);
        if (body.symbol !== undefined)
            set("symbol", body.symbol);
        if (body.type !== undefined)
            set("type", body.type);
        if (body.pricingMode !== undefined)
            set("pricing_mode", body.pricingMode);
        if (body.currency !== undefined)
            set("currency", body.currency.toUpperCase());
        if (body.isActive !== undefined)
            set("is_active", body.isActive ? 1 : 0);
        if (updates.length > 0) {
            set("updated_at", (0, connection_js_1.nowIso)());
            connection_js_1.db.prepare(`UPDATE products SET ${updates.join(", ")} WHERE id = ?`).run(...values, req.params.id);
            (0, auditService_js_1.auditLog)(admin, "product.updated", "product", req.params.id, { fields: Object.keys(body) });
        }
        const row = connection_js_1.db.prepare("SELECT * FROM products WHERE id = ?").get(req.params.id);
        res.json({ product: (0, mappers_js_1.mapProduct)(row) });
    }
    catch (error) {
        next(error);
    }
});
