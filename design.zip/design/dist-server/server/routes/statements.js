"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.statementsRouter = void 0;
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const node_fs_1 = __importDefault(require("node:fs"));
const node_path_1 = __importDefault(require("node:path"));
const zod_1 = require("zod");
const connection_js_1 = require("../db/connection.js");
const auth_js_1 = require("../middleware/auth.js");
const error_js_1 = require("../middleware/error.js");
const auditService_js_1 = require("../services/auditService.js");
const mappers_js_1 = require("../services/mappers.js");
exports.statementsRouter = (0, express_1.Router)();
const uploadBodySchema = zod_1.z.object({
    userId: zod_1.z.string().min(1),
    period: zod_1.z.string().min(2).max(80)
});
const storage = multer_1.default.diskStorage({
    destination: (_req, _file, cb) => cb(null, connection_js_1.statementsDir),
    filename: (_req, file, cb) => {
        const clean = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "-");
        cb(null, `${(0, connection_js_1.uid)("stmtfile")}-${clean}`);
    }
});
const upload = (0, multer_1.default)({
    storage,
    limits: { fileSize: 10 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
        if (file.mimetype !== "application/pdf" && !file.originalname.toLowerCase().endsWith(".pdf")) {
            cb(new error_js_1.ApiError(400, "Only PDF statements are allowed", "pdf_required"));
            return;
        }
        cb(null, true);
    }
});
exports.statementsRouter.use(auth_js_1.authenticate);
exports.statementsRouter.get("/", (req, res) => {
    const user = req.user;
    const clientId = typeof req.query.clientId === "string" ? req.query.clientId : null;
    const filters = [];
    const values = [];
    if (user.role !== "admin") {
        filters.push("s.user_id = ?");
        values.push(user.id);
    }
    else if (clientId) {
        filters.push("s.user_id = ?");
        values.push(clientId);
    }
    const rows = connection_js_1.db
        .prepare(`
      SELECT s.*, u.name AS client_name
      FROM statements s
      JOIN users u ON u.id = s.user_id
      ${filters.length ? `WHERE ${filters.join(" AND ")}` : ""}
      ORDER BY s.created_at DESC
      `)
        .all(...values);
    res.json({ statements: rows.map(mappers_js_1.mapStatement) });
});
exports.statementsRouter.post("/", auth_js_1.requireAdmin, upload.single("file"), (req, res, next) => {
    try {
        const body = uploadBodySchema.parse(req.body);
        const admin = req.user;
        const file = req.file;
        if (!file)
            throw new error_js_1.ApiError(400, "Statement PDF is required", "file_required");
        assertClient(body.userId);
        const id = (0, connection_js_1.uid)("stmt");
        const timestamp = (0, connection_js_1.nowIso)();
        connection_js_1.db.prepare(`
      INSERT INTO statements (id, user_id, period, file_name, file_path, mime_type, file_size, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(id, body.userId, body.period, file.originalname, file.path, file.mimetype, file.size, timestamp);
        (0, auditService_js_1.auditLog)(admin, "statement.uploaded", "statement", id, {
            userId: body.userId,
            period: body.period,
            fileName: file.originalname
        });
        const row = connection_js_1.db
            .prepare("SELECT s.*, u.name AS client_name FROM statements s JOIN users u ON u.id = s.user_id WHERE s.id = ?")
            .get(id);
        res.status(201).json({ statement: (0, mappers_js_1.mapStatement)(row) });
    }
    catch (error) {
        if (req.file?.path && node_fs_1.default.existsSync(req.file.path)) {
            node_fs_1.default.unlinkSync(req.file.path);
        }
        next(error);
    }
});
exports.statementsRouter.get("/:id/download", (req, res, next) => {
    try {
        const user = req.user;
        const row = connection_js_1.db
            .prepare("SELECT id, user_id, file_name, file_path FROM statements WHERE id = ?")
            .get(req.params.id);
        if (!row)
            throw new error_js_1.ApiError(404, "Statement not found", "statement_not_found");
        if (user.role !== "admin" && row.user_id !== user.id) {
            throw new error_js_1.ApiError(403, "Cannot access another client's statement", "ownership_required");
        }
        const resolved = (0, connection_js_1.resolveStatementPath)(row.file_path);
        if (!node_fs_1.default.existsSync(resolved))
            throw new error_js_1.ApiError(404, "Statement file not found", "statement_file_not_found");
        res.setHeader("Content-Type", "application/pdf");
        res.download(resolved, node_path_1.default.basename(row.file_name));
    }
    catch (error) {
        next(error);
    }
});
exports.statementsRouter.delete("/:id", auth_js_1.requireAdmin, (req, res, next) => {
    try {
        const admin = req.user;
        const row = connection_js_1.db
            .prepare("SELECT id, user_id, file_path FROM statements WHERE id = ?")
            .get(req.params.id);
        if (!row)
            throw new error_js_1.ApiError(404, "Statement not found", "statement_not_found");
        const resolved = (0, connection_js_1.resolveStatementPath)(row.file_path);
        connection_js_1.db.prepare("DELETE FROM statements WHERE id = ?").run(req.params.id);
        if (node_fs_1.default.existsSync(resolved))
            node_fs_1.default.unlinkSync(resolved);
        (0, auditService_js_1.auditLog)(admin, "statement.deleted", "statement", req.params.id, { userId: row.user_id });
        res.status(204).send();
    }
    catch (error) {
        next(error);
    }
});
function assertClient(userId) {
    const row = connection_js_1.db.prepare("SELECT id FROM users WHERE id = ? AND role = 'client'").get(userId);
    if (!row)
        throw new error_js_1.ApiError(400, "Client not found", "client_not_found");
}
