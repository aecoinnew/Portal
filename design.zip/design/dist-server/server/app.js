"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createApp = createApp;
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const express_1 = __importDefault(require("express"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const helmet_1 = __importDefault(require("helmet"));
require("./db/init.js");
const error_js_1 = require("./middleware/error.js");
const admin_js_1 = require("./routes/admin.js");
const auth_js_1 = require("./routes/auth.js");
const clients_js_1 = require("./routes/clients.js");
const portfolio_js_1 = require("./routes/portfolio.js");
const pricing_js_1 = require("./routes/pricing.js");
const products_js_1 = require("./routes/products.js");
const requests_js_1 = require("./routes/requests.js");
const settings_js_1 = require("./routes/settings.js");
const statements_js_1 = require("./routes/statements.js");
dotenv_1.default.config();
function createApp() {
    const app = (0, express_1.default)();
    const origin = process.env.API_ORIGIN ?? "http://localhost:3000";
    app.use((0, helmet_1.default)());
    app.use((0, cors_1.default)({
        origin,
        credentials: false,
        allowedHeaders: ["Content-Type", "Authorization"],
        methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"]
    }));
    app.use(express_1.default.json({ limit: "1mb" }));
    app.use((0, express_rate_limit_1.default)({
        windowMs: 15 * 60 * 1000,
        limit: 300,
        standardHeaders: true,
        legacyHeaders: false
    }));
    app.get("/api/health", (_req, res) => res.json({ ok: true }));
    app.use("/api/auth", auth_js_1.authRouter);
    app.use("/api/admin", admin_js_1.adminRouter);
    app.use("/api/clients", clients_js_1.clientsRouter);
    app.use("/api/products", products_js_1.productsRouter);
    app.use("/api/portfolio", portfolio_js_1.portfolioRouter);
    app.use("/api/pricing", pricing_js_1.pricingRouter);
    app.use("/api/requests", requests_js_1.requestsRouter);
    app.use("/api/settings", settings_js_1.settingsRouter);
    app.use("/api/statements", statements_js_1.statementsRouter);
    app.use(error_js_1.notFound);
    app.use(error_js_1.errorHandler);
    return app;
}
