"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticate = authenticate;
exports.requireRole = requireRole;
exports.requireAdmin = requireAdmin;
exports.requireSelfOrAdmin = requireSelfOrAdmin;
exports.jwtSecret = jwtSecret;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const zod_1 = require("zod");
const connection_js_1 = require("../db/connection.js");
const error_js_1 = require("./error.js");
const jwtPayloadSchema = zod_1.z.object({
    sub: zod_1.z.string(),
    role: zod_1.z.enum(["client", "admin"])
});
function authenticate(req, _res, next) {
    const header = req.header("authorization");
    const token = header?.startsWith("Bearer ") ? header.slice("Bearer ".length) : null;
    if (!token) {
        return next(new error_js_1.ApiError(401, "Authentication required", "unauthenticated"));
    }
    try {
        const decoded = jwtPayloadSchema.parse(jsonwebtoken_1.default.verify(token, jwtSecret()));
        const row = connection_js_1.db
            .prepare("SELECT id, name, email, role, status FROM users WHERE id = ?")
            .get(decoded.sub);
        if (!row) {
            return next(new error_js_1.ApiError(401, "User no longer exists", "unauthenticated"));
        }
        if (row.status === "suspended") {
            return next(new error_js_1.ApiError(403, "Account is suspended", "account_suspended"));
        }
        req.user = {
            id: row.id,
            name: row.name,
            email: row.email,
            role: row.role,
            status: row.status
        };
        return next();
    }
    catch {
        return next(new error_js_1.ApiError(401, "Invalid or expired token", "invalid_token"));
    }
}
function requireRole(role) {
    return (req, _res, next) => {
        const user = req.user;
        if (!user || user.role !== role) {
            return next(new error_js_1.ApiError(403, "Insufficient permissions", "forbidden"));
        }
        return next();
    };
}
function requireAdmin(req, res, next) {
    return requireRole("admin")(req, res, next);
}
function requireSelfOrAdmin(paramName = "userId") {
    return (req, _res, next) => {
        const user = req.user;
        const targetUserId = req.params[paramName] ?? req.query[paramName];
        if (user.role !== "admin" && user.id !== targetUserId) {
            return next(new error_js_1.ApiError(403, "Cannot access another client account", "ownership_required"));
        }
        return next();
    };
}
function jwtSecret() {
    const secret = process.env.JWT_SECRET;
    if (!secret || secret === "replace-with-a-long-random-production-secret") {
        if (process.env.NODE_ENV === "production") {
            throw new Error("JWT_SECRET must be set to a strong production secret");
        }
        return "local-development-only-change-me";
    }
    return secret;
}
