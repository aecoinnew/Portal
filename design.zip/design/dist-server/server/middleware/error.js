"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiError = void 0;
exports.notFound = notFound;
exports.errorHandler = errorHandler;
const zod_1 = require("zod");
class ApiError extends Error {
    status;
    code;
    details;
    constructor(status, message, code, details) {
        super(message);
        this.status = status;
        this.code = code;
        this.details = details;
    }
}
exports.ApiError = ApiError;
function notFound(_req, _res, next) {
    next(new ApiError(404, "Route not found", "not_found"));
}
function errorHandler(error, _req, res, _next) {
    if (error instanceof zod_1.ZodError) {
        return res.status(400).json({
            error: {
                message: "Invalid request payload",
                code: "validation_error",
                details: error.flatten()
            }
        });
    }
    if (error instanceof ApiError) {
        return res.status(error.status).json({
            error: {
                message: error.message,
                code: error.code,
                details: error.details
            }
        });
    }
    console.error(error);
    return res.status(500).json({
        error: {
            message: "Internal server error",
            code: "internal_error"
        }
    });
}
