"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
const app_js_1 = require("./app.js");
dotenv_1.default.config();
const port = Number(process.env.API_PORT ?? 4000);
(0, app_js_1.createApp)().listen(port, () => {
    console.log(`Emcoin API listening on http://localhost:${port}`);
});
